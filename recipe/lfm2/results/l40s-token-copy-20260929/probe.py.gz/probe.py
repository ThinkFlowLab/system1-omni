#!/usr/bin/env python3
"""Paired, isolated LFM candidate-token copy probe."""
import hashlib
import json
import platform
import transformers
import sys
import time
from pathlib import Path
import torch
HERE = Path(__file__).resolve().parent
CODE = HERE.parent if (HERE.parent / "recipe").is_dir() else Path(__file__).resolve().parents[3]
sys.path.insert(0, str(CODE / "recipe" / "lfm2"))
import _harness as H
from bench import string_enum_cell

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def measure(engine, cell):
    torch.cuda.synchronize()
    torch.cuda.reset_peak_memory_stats()
    start = time.perf_counter()
    output = engine.score(cell.context, cell.schema)
    torch.cuda.synchronize()
    return output, (time.perf_counter() - start) * 1000, torch.cuda.max_memory_allocated()

def main():
    result = Path(sys.argv[1])
    result.mkdir(parents=True, exist_ok=True)
    paths = {name: HERE / name / "engine.py" for name in ("baseline", "candidate")}
    modules = {name: H.load_module_from_path("probe_" + name, path) for name, path in paths.items()}
    model, tokenizer = H.load_shared_model("cuda", "float16")
    engines = {(name, size): module.Engine(size, "cuda", "float16", model=model, tokenizer=tokenizer)
               for name, module in modules.items() for size in (16, 32, 255)}
    cells = [string_enum_cell(count, context, "mixed")
             for count in (16, 255) for context in ("short", "long")]
    raw = result / "raw.jsonl"
    summary = {"source_sha256": {str(path): digest(path) for path in
               [*paths.values(), Path(__file__), CODE / "recipe/lfm2/_harness.py",
                CODE / "recipe/lfm2/bench.py"]}, "warmups": 3,
               "samples": 20, "cells": [], "all_exact_parity": True,
               "environment": {"python": platform.python_version(),
                               "torch": torch.__version__,
                               "transformers": transformers.__version__,
                               "cuda_runtime": torch.version.cuda,
                               "gpu_name": torch.cuda.get_device_name(0),
                               "nvidia_smi": H._nvidia_smi(),
                               "model_revision": H.MODEL_REVISION},
               "all_oracle_choices_match": True}
    for cell in cells:
        for batch_label, size in (("32", 32), ("all", cell.candidate_count)):
            for warmup in range(3):
                for name in (("baseline", "candidate") if warmup % 2 == 0 else
                             ("candidate", "baseline")):
                    engines[name, size].score(cell.context, cell.schema)
            oracle = H.oracle_scores(engines["baseline", size], cell.context, cell.schema)
            oracle_choice = H.selected_from(oracle["scores"])
            measurements = {"baseline": [], "candidate": []}
            exact = True
            choice_match = True
            for sample in range(20):
                order = (("baseline", "candidate") if sample % 2 == 0 else
                         ("candidate", "baseline"))
                pair = {}
                for name in order:
                    output, ms, allocated = measure(engines[name, size], cell)
                    pair[name] = output
                    measurements[name].append((ms, allocated))
                    H.append_jsonl(raw, {"cell": cell.cell_id, "batch": batch_label,
                            "sample": sample, "variant": name, "order": list(order),
                            "latency_ms": ms, "peak_allocated_bytes": allocated,
                            "choice": H.selected_from(output["scores"]),
                            "scores_sha256": H.sha256_json(output["scores"])})
                exact = exact and pair["baseline"]["scores"] == pair["candidate"]["scores"]
                exact = exact and pair["baseline"]["text"] == pair["candidate"]["text"]
                choice_match = choice_match and H.selected_from(pair["baseline"]["scores"]) == oracle_choice
                if not exact:
                    raise AssertionError("exact score/choice mismatch: " + cell.cell_id + "/" + batch_label)
            row = {"cell": cell.cell_id, "batch": batch_label,
                   "candidate_count": cell.candidate_count,
                   "prompt_tokens": len(engines["baseline", size].encode(
                       engines["baseline", size].prompt(cell.context, cell.schema))),
                   "oracle_choice": oracle_choice, "oracle_choice_matches": choice_match,
                   "exact_score_and_choice_parity": exact, "variants": {}}
            for name, samples in measurements.items():
                latencies = [x[0] for x in samples]
                row["variants"][name] = {"p50_ms": H.percentile(latencies, 50),
                                        "p95_ms": H.percentile(latencies, 95),
                                        "peak_allocated_bytes": max(x[1] for x in samples)}
            base = row["variants"]["baseline"]
            new = row["variants"]["candidate"]
            row["p50_delta_pct"] = 100 * (new["p50_ms"] / base["p50_ms"] - 1)
            row["p95_delta_pct"] = 100 * (new["p95_ms"] / base["p95_ms"] - 1)
            row["peak_allocated_delta_pct"] = 100 * (new["peak_allocated_bytes"] /
                                                      base["peak_allocated_bytes"] - 1)
            summary["cells"].append(row)
            summary["all_exact_parity"] &= exact
            summary["all_oracle_choices_match"] &= choice_match
            H.atomic_write_json(result / "summary.json", summary)
            print(json.dumps({"cell": cell.cell_id, "batch": batch_label,
                              "p50_delta_pct": row["p50_delta_pct"],
                              "oracle_choice_matches": choice_match}), flush=True)
    if not summary["all_oracle_choices_match"]:
        raise AssertionError("engine choice differed from independent uncached oracle")

if __name__ == "__main__":
    main()
